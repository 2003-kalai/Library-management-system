package libraryManagementSystem;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Admin {

	static Scanner scanner = new Scanner(System.in);
	private final String adminUsername = "admin";
	private final String adminPassword = "password";
	private ArrayList<Book> al = new ArrayList<Book>();
	private List<Member> members = new ArrayList<>();
	private Services service = new Services(members);

	Admin(ArrayList<Book> al, List<Member> members) {
		this.al = al;
		this.members = members;
		
		System.out.println(members);
	}

	
	public void loginAsAdmin() {
		if (al.isEmpty()) {
			al.add(new Book("Science", "John Doe", "Educational"));
			al.add(new Book("Social Studies", "Jane Smith", "Educational"));
		}
		System.out.print("Enter username: ");
		String username = scanner.nextLine();
		System.out.print("Enter password: ");
		String password = scanner.nextLine();

		if (username.equals(adminUsername) && password.equals(adminPassword)) {
			System.out.println("Logged in as admin.");
			adminMenu();
		} else {
			System.out.println("Invalid admin credentials.");
		}
	}

	public void adminMenu() {
		while (true) {
			System.out.println("\nLibrary Management System");
			System.out.println("1. Add Book");
			System.out.println("2. Update Book");
			System.out.println("3. Remove Book");
			System.out.println("4. Add Member");
			System.out.println("5. Display All Books");
			System.out.println("6. Display All Members");
			System.out.println("7. Exit");

			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();
			scanner.nextLine(); // consume the newline character

			switch (choice) {
			case 1:
				al.add(service.addBook());
				break;
			case 2:
				service.updateBook(al);
				break;
			case 3:
				service.removeBook(al);
				break;
			case 4:
				service.addMember();
				break;
			case 5:
				service.displayAllBooks(al);
				break;
			case 6:
				service.displayAllMembers();
				break;
			case 7:
				return;
			default:
				System.out.println("Invalid choice. Please try again.");
			}
		}
	}

	public String getAdminUsername() {
		return adminUsername;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

}
