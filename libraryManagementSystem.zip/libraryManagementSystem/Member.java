package libraryManagementSystem;

import java.util.ArrayList;
import java.util.List;

class Member {
	String username;
	List<Book> borrowedBooks;

	Member(String username) {
		this.username = username;
		this.borrowedBooks = new ArrayList<>();
	}

	boolean borrowBook(Book book) {
		if (borrowedBooks.size() < 5 && book.isAvailable) {
			borrowedBooks.add(book);
			book.isAvailable = false;
			return true;
		}
		return false;
	}

	void returnBook(Book book) {
		borrowedBooks.remove(book);
		book.isAvailable = true; // Mark the book as available
	}

	@Override
	public String toString() {
		return "Member [username=" + username + "]";
	}
	
	
}

