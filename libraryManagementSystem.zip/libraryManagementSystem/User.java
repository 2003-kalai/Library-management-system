package libraryManagementSystem;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class User {

    static List<Member> members = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);
    static Member loggedInMember = null;

    ArrayList<Book> al = new ArrayList<>();
    private Services service;

    // Constructor receives list of books
    public User(ArrayList<Book> al) {
        this.al = al;
    }

    public void loginAsUser() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        loggedInMember = findOrCreateMember(username, members);
        service = new Services(members, loggedInMember); // Initialize service after setting loggedInMember

      //  System.out.println("Logged in as user: " + loggedInMember.getUsername());
        userMenu();
    }

    public Member findOrCreateMember(String username, List<Member> members) {
        for (Member member : members) {
            if (member.username.equals(username)) {
                return member;
            }
        }
        Member newMember = new Member(username);
        members.add(newMember);
        return newMember;
    }

    public void userMenu() {
        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Borrow Book");
            System.out.println("2. Return Book");
            System.out.println("3. Display All Books");
            System.out.println("4. Display All Members");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    service.borrowBook(al, loggedInMember);
                    break;
                case 2:
                    service.returnBook(al);
                    break;
                case 3:
                    service.displayAllBooks(al);
                    break;
                case 4:
                    service.displayAllMembers();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
