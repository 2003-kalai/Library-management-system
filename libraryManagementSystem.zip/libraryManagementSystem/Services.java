package libraryManagementSystem;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Services {

	Scanner scanner = new Scanner(System.in);
	static List<Member> members = new ArrayList<>();
	Member loggedInMember = null;

	Services(List<Member> members, Member loggedInMember) {
		this.members = members;
		this.loggedInMember = loggedInMember;
	}

	Services(List<Member> members) {
		this.members = members;

	}

	public Services(Member loggedInMember2) {
		// TODO Auto-generated constructor stub
		// TODO Auto-generated constructor stub
				boolean isThere = false;
				for(Member m :this.members ) {
					if(m.username == loggedInMember2.username) {
						isThere = true;
					}
				}
				
				if(!isThere) {
					this.members.add(loggedInMember2);
				}
				System.out.println(members);
	}

	public Book addBook() {

		System.out.print("Enter book title: ");
		String title = scanner.nextLine();
		System.out.print("Enter book author: ");
		String author = scanner.nextLine();
		System.out.print("Enter book genre: ");
		String genre = scanner.nextLine();
		Book books = new Book(title, author, genre);
		System.out.println("Booksuccessfully.");
		return books;

	}

	public void updateBook(ArrayList<Book> books) {
		System.out.print("Enter book title to update: ");
		String title = scanner.nextLine();

		Book book = findBookByTitle(title, books);
		if (book != null) {
			System.out.print("Enter new author: ");
			book.author = scanner.nextLine();
			System.out.print("Enter new genre: ");
			book.genre = scanner.nextLine();
			System.out.println("Book updated successfully.");

		} else {
			System.out.println("Book not found.");
		}
	}

	public void removeBook(ArrayList<Book> books) {
		System.out.print("Enter book title to remove: ");
		String title = scanner.nextLine();
		Book book = findBookByTitle(title, books);
		if (book != null) {
			books.remove(book);
			System.out.println("Book removed successfully.");
		} else {
			System.out.println("Book not found.");
		}
	}

	public void addMember() {
		System.out.print("Enter member username: ");
		String username = scanner.nextLine();
		members.add(new Member(username));
		System.out.println("Member added successfully.");
	}

	public void displayAllBooks(ArrayList<Book> books) {
		if (books.isEmpty()) {
			System.out.println("No books available");
		} else {
			System.out.println("\nList of Books:");
			for (Book book : books) {
				System.out.println("Title: " + book.title + ", Author: " + book.author + ", Genre: " + book.genre
						+ ", Available: " + book.isAvailable);
			}
		}
	}

	public void displayAllMembers() {
		if (members.isEmpty()) {
			System.out.println("No memebers exist");
		} else {
			System.out.println("\nList of Members:");
			for (Member member : members) {
				System.out.println("Username: " + member.username + ", Borrowed Books: " + member.borrowedBooks.size());
			}
		}
	}

	private static Book findBookByTitle(String title, ArrayList<Book> books) {
		for (Book book : books) {
			if (book.title.equalsIgnoreCase(title)) {
				return book;
			}
		}
		return null;
	}

	public void borrowBook(ArrayList<Book> books,Member loggedInmember) {
		System.out.println(members);
		System.out.print("Enter book title to borrow: ");
		String title = scanner.nextLine();
		Book book = findBookByTitle(title, books);
		loggedInMember = loggedInmember;
		
		if (book != null && loggedInMember.borrowBook(book)) {
			System.out.println("Book borrowed successfully.");
			
		} else {
			System.out.println("Book is either unavailable or borrow limit reached.");
		}
	}

	public void returnBook(ArrayList<Book> books) {
		System.out.print("Enter book title to return: ");
		String title = scanner.nextLine();

		Book book = findBookByTitle(title, books);
		if (book != null && !book.isAvailable) {
			loggedInMember.returnBook(book);
			System.out.println("Book returned successfully.");
		} else {
			System.out.println("Book not found or it wasn't borrowed.");
		}
	}

}
