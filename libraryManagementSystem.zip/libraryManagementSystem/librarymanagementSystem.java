package libraryManagementSystem;

import java.util.*;

public class librarymanagementSystem {

	private static Scanner scanner = new Scanner(System.in);
	private static ArrayList<Book> books = new ArrayList<>();
	private static List<Member> members = new ArrayList<>();
	private static Admin admin = new Admin(books,members);
	private static User user = new User(books);
	
	
	

	public static void main(String[] args) {

		books.add(new Book("Science", "John Doe", "Educational"));
		books.add(new Book("Social Studies", "Jane Smith", "Educational"));

		while (true) {
			System.out.print("Enter role (admin/user): ");
			String role = scanner.nextLine();

			if (role.equals("admin")) {
				admin.loginAsAdmin();
			} else if (role.equals("user")) {
				user.loginAsUser();
			} else {
				System.out.println("Invalid role. Please try again.");

			}
		}
	}

}